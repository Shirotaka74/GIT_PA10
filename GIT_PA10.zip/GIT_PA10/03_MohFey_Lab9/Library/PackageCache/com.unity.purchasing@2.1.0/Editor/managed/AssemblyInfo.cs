﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("UnityEditor.Purchasing.EditorTests")]

